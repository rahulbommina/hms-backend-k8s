# Hospital Backend Kubernetes Deployment

Includes Dockerfile, Deployment, Service YAML.
